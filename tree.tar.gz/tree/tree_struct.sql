﻿-- Table: public.tree_struct

-- DROP TABLE public.tree_struct;

CREATE TABLE public.tree_struct
(
  key character varying(100000),
  parent character varying(100000),
  folder character varying(20),
  title character varying(1000),
  lazy character varying(1000)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.tree_struct
  OWNER TO postgres;

-- Index: public.fp_idx

-- DROP INDEX public.fp_idx;

CREATE INDEX fp_idx
  ON public.tree_struct
  USING btree
  (key COLLATE pg_catalog."en_US.utf8" varchar_ops);

