import subprocess
import os
import io
import re
from sqlalchemy import create_engine, MetaData
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy import func, Table, column, select, insert
from multiprocessing.dummy import Pool as ThreadPool
from datetime import datetime


startTime = datetime.now()
# Get config file settings...
#import ConfigParser
#parser = ConfigParser.SafeConfigParser()
#parser.read('/sso/sfw/edr_walk/walker.cfg')
#appList = parser.get('AppList', 'appList').split(',')
#numPools = int(parser.get('Settings', 'numPools'))
#mTime = parser.get('Settings', 'mTime')
#pguser = parser.get('DBSettings', 'user')
#pgpass = parser.get('DBSettings', 'pass')
#pghost = parser.get('DBSettings', 'host')
#pgdb = parser.get('DBSettings', 'db')
#pgport = mTime = parser.get('DBSettings', 'port')


# make a configuration option user:pass@host/dbname
engine = create_engine("postgresql://postgres:postgres@localhost:5432/portes", convert_unicode=True, pool_size=200, max_overflow=20)
DBSession = scoped_session(sessionmaker(bind=engine))
meta = MetaData(bind=engine)
# Init Postgres table objects
tree_struct = Table("tree_struct", meta, autoload=True, autoload_with=engine)

mySQLInsert = []
def doFind():
    engine.dispose()
    myproc = subprocess.Popen('find /FDA_Hold -maxdepth 1 -mindepth 1 -mtime -1000 -type d | while read line; do find $line -ls | grep -E -i  \'\/m4\/|\/m5\/\'; done', shell=True, stdout=subprocess.PIPE)

    for line in iter(myproc.stdout.readline, ''):
        splitLine = line.split()
        fullpath = splitLine[10]
        parent = subprocess.check_output(["dirname", fullpath])
        parent = parent.rstrip()
	folder = subprocess.Popen("test -d "+fullpath+" && echo 'true' || echo 'false'", shell=True, stdout=subprocess.PIPE)
	out, err = folder.communicate()
	folder = out.rstrip()
	lazy = 'true'
	if folder == 'false':
	    folder = ''
	    lazy = ''

	testy = subprocess.Popen("ls -A "+fullpath+" | wc -l", shell=True, stdout=subprocess.PIPE)
	out, err = testy.communicate()
	testy = out.rstrip()
	if testy == '0':
	   lazy=''

	pathList = fullpath.split('/')
	title = pathList[-1]
	title = title.rstrip()
        mdQuery = { 'key': fullpath, 'parent' : parent, 'folder': folder, 'title': title, 'lazy': lazy }
        i = tree_struct.insert()
        try:
            i.execute(mdQuery)
        except exceptions.SQLAlchemyError:
            print str(mdQuery)
            continue
        except:
            continue


# Make the Pool of workers - MAKE THIS NUMBER EQUAL TO NUMBER OF CORES
#pool = ThreadPool(numPools)
#pool.map(doFind, appList)
#pool.close()
#pool.join()
doFind()
# Close DBSession that is opened automatically in doFind()
DBSession.close()

print "Time to run: " + str(datetime.now() - startTime)
