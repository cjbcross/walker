from main import db


class User(db.Model):
    __tablename__ = "users"

    user_hostname = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String, nullable=False)
    last_name = db.Column(db.String, nullable=False)
    group_name = db.Column(db.String, nullable=False)

    def __init__(self, user_hostname, first_name, last_name, group_name):
        self.user_hostname = user_hostname
        self.first_name = first_name
        self.last_name = last_name
        self.group_name = group_name

    def __repr__(self):
        return "<User(user_hostname='%s', first_name='%s', last_name='%s')>" \
            % (self.user_hostname, self.first_name, self.last_name, self.group_name)
