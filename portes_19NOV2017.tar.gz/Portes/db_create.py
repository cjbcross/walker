from main import db
from models import User

# create database and db tables
db.create_all()

# commit the changes
# db.session.commit()
