import json
import pandas as pd
from sqlalchemy import create_engine
import datetime


def return_sql(root):
    sql = "select title, key, folder, lazy from tree_struct where parent like '%%435678/M4' and title not like '%%Collaborative%%' order by title"

    if root is not None:
        sql = "select distinct title, key, folder, lazy from tree_struct where key like '%%/" + root + "' order by title"

    engine = create_engine('postgresql://postgres:postgres@localhost:5432/portes', convert_unicode=True)
    con = engine.connect()
    df = pd.read_sql(sql, con)
    return df.to_json(orient='records')

def return_child(parent):
    sql = "select title, key, folder, lazy from tree_struct where parent = '" + parent + "' order by title"
    engine = create_engine('postgresql://postgres:postgres@localhost:5432/portes', convert_unicode=True)
    con = engine.connect()
    df = pd.read_sql(sql, con)
    return df.to_json(orient='records')