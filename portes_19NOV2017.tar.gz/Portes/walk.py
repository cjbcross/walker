import json
from convert_to_dict import dic
from os import walk, path

def file_to_dict(fpath):
    file = {
        'title': path.basename(fpath),
        'type': 'file',
        'key': fpath,
    }
    return file


def folder_to_dict(rootpath):
    folder = {
        'title': path.basename(rootpath),
        'folder': 'true',
        'key': rootpath,
        'children': [],
    }
    tooltip = dic.get(folder['title'], None)
    # if folder['title'] == "_Collaborative _area":
    #     folder['icon'] = '/static/icons/PurpleFolder.png'
    if tooltip is not None:
        folder['tooltip'] = tooltip
    return folder


def tree_to_dict(rootpath):
    root_dict = folder_to_dict(rootpath)
    root, folders, files = next(walk(rootpath))
    root_dict['children'] = [file_to_dict(path.sep.join([root, fpath])) for fpath in files]
    root_dict['children'] += [tree_to_dict(path.sep.join([root, folder])) for folder in folders]
    return root_dict

def tree_to_json(rootdir, pretty_print=True):
    root, folders, files = next(walk(rootdir))
    root_dict = [tree_to_dict(path.sep.join([root, folder])) for folder in folders]

    counter = 0

    for fpath in files:
        if counter > MAX:
            break
        counter += 1
        root_dict += [file_to_dict(path.sep.join([root, fpath]))]
    # root_dict += [file_to_dict(path.sep.join([root, fpath])) for fpath in files]
    if pretty_print:
        js = json.dumps(root_dict)
    else:
        js = json.dumps(root_dict)
    return js

# out = folder_to_dict("/FDA_Hold/FDA/OND/NDA/NDA657322/M4")
# print(out)

def return_rest(filename):
    # return tree_to_json(pathToFolder)
    return tree_to_json(filename)
