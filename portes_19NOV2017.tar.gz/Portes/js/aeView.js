function initTable() {
    $('#sasTable2').bootstrapTable({
        url: '/ae',
        columns: [

                {
//                    field: 'mkt_auth_num',
//                    title: 'Mkt Authorisation Number',
//                    sortable: true,
//                    align: 'center'
//                }, {
                    field: 'undesire_effect',
                    title: 'Undesired Effect',
                    sortable: true,
                    filterControl: 'select',
                    align: 'center',
                }, {
                    field: 'pt_code',
                    title: 'PT Code',
                    sortable: true,
                    align: 'center'
                }, {
                    field: 'vocab',
                    title: 'Vocabulary',
                    sortable: true,
                    align: 'left',
                },{
                    field: 'soc',
                    title: 'SOC',
                    sortable: true,
                    filterControl: 'select',
                    align: 'center'
                },{
                    field: 'freq',
                    title: 'Frequency',
                    sortable: true,
                    filterControl: 'select',
                    align: 'center'
                }

        ]
    });
}
initTable();

var $table = $('#sasTable2');
$(function () {
    $('#toolbar2').find('select').change(function () {
        $table.bootstrapTable('destroy').bootstrapTable({
            exportDataType: $(this).val()
        });
    });
})
