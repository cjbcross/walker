function initTable() {
    $('#sasTable').bootstrapTable({
        url: '/csv',
        columns: [

                {
                    field: 'state',
                    radio: true,
                    align: 'center',
                    valign: 'middle'
                },{
                    field: 'target',
                    title: 'Attribute',
                    sortable: true,
                    filterControl: 'select',
                    align: 'center'
                }, {
                    field: 'match',
                    title: 'Extracted',
                    sortable: true,
                    align: 'center',
                    formatter: modFormatter
                }, {
                    field: 'modified',
                    title: 'Modified',
                    sortable: true,
                    align: 'center',
                }, {
                    field: 'context',
                    title: 'Context',
                    sortable: true,
                    align: 'left',
                    formatter: matchFormatter
//                },{
//                    field: 'source',
//                    title: 'Source',
//                    sortable: true,
//                    align: 'center'
//                },{
//                    field: 'section',
//                    title: 'Document Section',
//                    sortable: true,
//                    align: 'center'
//                },
//                },{
//                    field: 'doc',
//                    title: 'Document',
//                    sortable: true,
//                    filterControl: 'select',
//                    align: 'center'
//                },{
//                    field: 'mkt_auth_num',
//                    title: 'Mkt Authorization Number',
//                    sortable: true,
//                    filterControl: 'select',
//                    align: 'center'
                }

        ]
    });
}
initTable();


function matchFormatter(data, row, cells) {
    var match = row.match;
    var res = data.replace(match, "<span style='color:#0074BE;'><b>"+match+"</b></span>");
    return res;
}

function modFormatter(data, row, cells) {
    var match = data;
    var res;
    if( match == "straw-coloured")
        res = data.replace(match,"");
    else
        res = data.replace(match, "<span style='color:#0074BE;'><b>"+match+"</b></span>");
    return res;
}

function undefFormatter(data, row, cells) {
    var match = data;
    var res;
    if( match == "undefined") res = data.replace(match,"");
    return res;
}

var $table = $('#sasTable');
$(function () {
    $('#toolbar').find('select').change(function () {
        $table.bootstrapTable('destroy').bootstrapTable({
            exportDataType: $(this).val()
        });
    });
})
