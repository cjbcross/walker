import pandas as pd
from sqlalchemy import create_engine

sql = "select fullpath, file_size, file_type, file_time_stamp, file_id, file_checksum, file_checksum_type from file_metadata"

def return_sql():
    engine = create_engine('postgresql://postgres:postgres@localhost:5432/portes', convert_unicode=True)
    con = engine.connect()
    df = pd.read_sql(sql, con)
    return df.to_json(orient='records')

