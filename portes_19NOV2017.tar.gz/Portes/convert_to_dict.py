

dic = {"NDA112233":"Product Name: Apple    Dosage Form: Tablet    Applicant: ABC Pharma     Organization:OND/ODEIII/DBRUP",
	"NDA321321":"Product Name: Pear    Dosage Form: Tablet    Applicant: DEF Pharma     Organization:OND/ODEIII/DBRUP",
	"NDA435678":"Product Name: Orange    Dosage Form: Tablet    Applicant: GHI Pharma     Organization:OND/ODEIII/DBRUP",
	"NDA657322":"Product Name: Cherry    Dosage Form: Tablet    Applicant: JKL Pharma     Organization:OND/ODEIII/DBRUP"
	}