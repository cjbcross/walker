// Changes angularJS brackets to [[ and ]] instead of {{ and }}.
angular.module('myApp', []).config(function($interpolateProvider){
    $interpolateProvider.startSymbol('[[').endSymbol(']]');
});

var openedNode;
//var setPath = "/FDA_Hold"

$(function(){
    // Create the tree inside the <div id="tree"> element.
    $("#tree").fancytree({
        // "wide" extension messes with set icons for some reason
        extensions: ["persist", "filter", "glyph"],
        source: {
            url: "/pgTree"
        },
        autoScroll: true,
        checkbox: true,
        selectMode: 3,
        glyph: {
            preset: "awesome4",
            map: {
                doc: "fa fa-file-o",
                docOpen: "fa fa-file-o",
                checkbox: "fa fa-square-o",
                checkboxSelected: "fa fa-check-square-o",
                checkboxUnknown: "fa fa-square",
                error: "fa fa-warning",
                expanderClosed: "fa fa-caret-right",
                expanderLazy: "fa fa-caret-right",
                expanderOpen: "fa fa-caret-down",
                folder: "fa fa-folder-o",
                folderOpen: "fa fa-folder-open-o",
                loading: "fa fa-spinner fa-pulse"
            }
        },

        lazyLoad: function(event, data){
            data.result = $.ajax({
                url: "/pgLazy?parent=" + data.node.key,
                dataType: "json"
            });
        },
        

        // filter: {
        //     autoApply: true,  // Re-apply last filter if lazy data is loaded
        //     counter: true,  // Show a badge with number of matching child nodes near parent icons
        //     fuzzy: false,  // Match single characters in order, e.g. 'fb' will match 'FooBar'
        //     hideExpandedCounter: true,  // Hide counter badge, when parent is expanded
        //     highlight: true,  // Highlight matches by wrapping inside <mark> tags
        //     mode: "dimm"  // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
        // },
        persist: {
            // Available options with their default:
            cookieDelimiter: "~",    // character used to join key strings
            cookiePrefix: undefined, // 'fancytree-<treeId>-' by default
            cookie: { // settings passed to jquery.cookie plugin
              raw: false,
              expires: "",
              path: "",
              domain: "",
              secure: false
            },
            expandLazy: true, // true: recursively expand and load lazy nodes
            overrideSource: true,  // true: cookie takes precedence over `source` data attributes.
            store: "auto",     // 'cookie': use cookie, 'local': use localStore, 'session': use sessionStore
            types: "expanded"  // which status types to store
        },

        activate: function(event, data) {
            foldername = "_Collaborative _area";
            if (foldername == data.node.title) {
                $("#echoActive").text(data.node.title);
                $('#echoActivePath').text(data.node.key);
                document.getElementById('active').value = $("#echoActivePath").text();
                if(data.node.folder && document.getElementById("browse_button").files.length !== 0) {
                     document.getElementById("upload_button").disabled = false;
                } else {
                    document.getElementById("upload_button").disabled = true;
                }
            } else {
                $("#echoActive").text("");
                $('#echoActivePath').text("");
                document.getElementById('active').value = "";
            }
        },
        init: function(event, data, flag) {
            var node = $("#tree").fancytree("getRootNode");
            node.sortChildren(null, true);
        },
        select: function(event, data) {
            // Get a list of all selected nodes, and convert to a key array:
            var selKeys = $.map(data.tree.getSelectedNodes(true), function(node){
             return node.title;
            });
            $("#echoSelection").text(selKeys.join(", "));

            // Get a list of all selected TOP nodes
            var selRootNodes = data.tree.getSelectedNodes(true);
            // ... and convert to a key array:
            var selRootKeys = $.map(selRootNodes, function(node){
                return node.key;
            });
            $("#echoSelectionRootKeys").text(selRootKeys.join(", "));
            $("#echoSelectionRootKeysText").text(selRootKeys.join(', '));
            document.getElementById('paths').value = $("#echoSelectionRootKeys").text();
            if($("#echoSelectionRootKeys").text() === "") {
                document.getElementById("download_button").disabled = true;
            } else {
                document.getElementById("download_button").disabled = false;
            }
        },
        click: function(event, data) {
            var node = data.node,
            tt = $.ui.fancytree.getEventTargetType(event.originalEvent);

            if( tt !== "checkbox" && tt != "expander" ) {
                node.toggleExpanded();
            }
        },

    });


    var tree;
    if($('#viewChoices').val() === "A") {
        tree = $("#tree");
    } else {
        tree = $("#treetable");
    }

    $("button").button();

    $("button#sort").click(function(event){
        var node = tree.fancytree("getRootNode");
        node.sortChildren(null, true);
        var node = tree.fancytree("getRootNode");
        node.sortChildren(null, true);
    });

    $("button#reset").click(function(event){
        tree.fancytree("getRootNode").visit(function(node){
            node.setExpanded(false);
            node.setSelected(false);
        });
        // tree.data.node.setActive(false);
        document.getElementById("download_button").disabled = true;
        document.getElementById("browse_button").value = "";
        document.getElementById("upload_button").disabled = true;
        tree.data.active = false;
        $("#echoActivePath").text("");
        $('#upload-file-info').html("");
    });

    $("button#toggle").click(function(event){
        tree.fancytree("getRootNode").visit(function(node){
            node.toggleExpanded();
        });
    });

    $("button#add").click(function(event){
        // Sample: add an hierarchic branch using code.
        // This is how we would add tree nodes programatically
      var rootNode = tree.fancytree("getRootNode");
      var childNode = rootNode.addChildren({
        title: "Programatically addded nodes",
        tooltip: "This folder and all child nodes were added programmatically.",
        folder: true
      });
      childNode.addChildren({
        title: "Document using a custom icon",
        icon: "customdoc1.gif"
      });
    });
    $("span#clearDownload").click(function(event){
        tree.fancytree("getRootNode").visit(function(node){
            node.setSelected(false);
        });
        document.getElementById("download_button").disabled = true;
    });

    $("span#clearUpload").click(function(event){
        // tree.data.node.setActive(false);
        document.getElementById("browse_button").value = "";
        document.getElementById("upload_button").disabled = true;
        tree.data.active = false;
        $("#echoActivePath").text("");
        $('#upload-file-info').html("");
    });

    $("input:file").change(function() {
        if($(this).val()) {
             document.getElementById("upload_button").disabled = false;
        } else {
            document.getElementById("upload_button").disabled = true;
        }
    });

    $('document').ready(function() {
        // Hidding and showing specific tree.
        $('.trees').hide();
        $('#'+$('#viewChoices').val()).show();

        document.getElementById("upload_button").disabled = true;
        document.getElementById("download_button").disabled = true;
    });

    $('#viewChoices').change(function () {
        $('.trees').hide();
        $('#'+$(this).val()).show();
        if($('#viewChoices').val() === "A") {
            tree = $("#tree");
        } else {
            tree = $("#treetable");
        }
    });

    // $("input[name=search]").keyup(function(e){
    //     var n,
    //     opts = {
    //         counter: true,
    //         hideExpandedCounter: true,
    //         highlight: true,
    //     },
    //     match = $(this).val();

    //     if(e && e.which === $.ui.keyCode.ESCAPE || $.trim(match) === ""){
    //         $("button#btnResetSearch").click();
    //         return;
    //     }
    //     // Pass a string to perform case insensitive matching
    //     n = tree.fancytree("getTree").filterNodes(match);

    //     $("button#btnResetSearch").attr("disabled", false);
    //     $("span#matches").text("(" + n + " matches)");
    // }).focus();

    $("button#btnResetSearch").click(function(e){
        $("input[name=search]").val("");
        $("span#matches").text("");
        tree.fancytree("getTree").clearFilter();
    }).attr("disabled", true);

    // $(window).scroll(function() {
    //     if($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
    //        alert("near bottom!");
    //     }
    // });
});

var selDiv = "";

document.addEventListener("DOMContentLoaded", init, false);

function init() {
    document.querySelector('#browse_button').addEventListener('change', handleFileSelect, false);
    selDiv = document.querySelector("#upload-file-info");
}

function handleFileSelect(e) {

    if(!e.target.files) return;

    selDiv.innerHTML = "";

    var files = e.target.files;
    for(var i=0; i<files.length - 1; i++) {
        var f = files[i];
        selDiv.innerHTML += f.name + ", ";
    }
    selDiv.innerHTML += files[files.length - 1].name;
}